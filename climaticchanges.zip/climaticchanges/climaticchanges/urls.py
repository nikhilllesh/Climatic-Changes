"""climaticchanges URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from myapp.views import hello
from django.urls import path
from myapp.views import login
from myapp.views import index
from myapp.views import temp
from myapp.views import predict
from myapp.views import pred_year
from myapp.views import pred_year_2
from myapp.views import pred_temp
from myapp.views import dynamic_visual
from myapp.views import dynamic_visual_menu
from myapp.views import visual_menu
from myapp.views import stat_pred_menu
from myapp.views import dynamic_prediction_2
from myapp.views import dynamic_visual_2
from myapp.views import dynamic_prediction_4
from myapp.views import static_visualisation
from myapp.views import static_visualisation_temp
from myapp.views import introduction
from myapp.views import occurance
from myapp.views import effects
from myapp.views import prevention
from myapp.views import about_rainfall
from myapp.views import about_temp
from myapp import views 
urlpatterns = [
     path('admin/', admin.site.urls),
     path('index/', views.index, name='index'),
     url(r'^hello/$', hello),
     url(r'^login/$', login),
     #url(r'^index/$',  index),
     url(r'^temp/$',  temp,name="temp"),
     url(r'^predict/$',  views.predict,name="predict"),
     url(r'^dynamic_visual/$',  dynamic_visual,name="dynamic_visual"),
     url(r'^pred_year/$',  views.pred_year,name="pred_year"),
     url(r'^dynamic_prediction_2/$',  views.dynamic_prediction_2,name="dynamic_prediction_2"),
     url(r'^pred_year_2/$',  views.pred_year_2,name="pred_year_2"),
     url(r'^dynamic_visual_2/$',  views.dynamic_visual_2,name="dynamic_visual_2"),
     url(r'^static_visualisation/$',  static_visualisation,name="static_visualisation"),
     url(r'^static_visualisation_temp/$',  static_visualisation_temp,name="static_visualisation_temp"),
     url(r'^pred_temp/$',  views.pred_temp,name="pred_temp"),
     url(r'^dynamic_prediction_4/$',  dynamic_prediction_4,name="dynamic_prediction_4"),
     url(r'^introduction/$',introduction,name="introduction"),
     url(r'^occurance/$', occurance,name="occurance"),
     url(r'^effects/$', effects,name="effects"),
     url(r'^prevention/$', prevention  ,name="prevention"),
     url(r'^dynamic_visual_menu/$',  views.dynamic_visual_menu,name="dynamic_visual_menu"),
     url(r'^visual_menu/$',  views.visual_menu,name="visual_menu"),
     url(r'^stat_pred_menu/$',  views.stat_pred_menu,name="stat_pred_menu"),
     url(r'^about_rainfall/$',  views.about_rainfall,name="about_rainfall"),
     url(r'^about_temp/$',  views.about_temp,name="about_temp"),
]
