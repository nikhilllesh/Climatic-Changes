from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
import numpy as np
import itertools
import warnings
import matplotlib.pyplot as plt
from matplotlib import pylab
from pylab import *
from PIL import Image,ImageDraw
import PIL, PIL.Image
from io import StringIO
import statsmodels.api as sm
import matplotlib
from io import BytesIO
import io
import base64
#create your views here
def hello(request):
    text = """<h1>welcome to my app !</h1>"""
    
    return HttpResponse(text)

def login(request):
    write = """<h2>welcome to login page !</h2>"""
    return HttpResponse(write)

def index(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'index.html',context=my_dict)

def temp(request):
    return render(request,'about1.html')

def predict(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'PREDICTIION.HTML',context=my_dict)

def occurance(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'occurance.HTML',context=my_dict)

def introduction(request):
    return render(request,'introduction.html')

def effects(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'effects.HTML',context=my_dict)

def prevention(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'prevention.HTML',context=my_dict)
    
def dynamic_visual(request):
    if request.method=='POST':
        fig=plt.figure(figsize=(6,7),dpi=80,facecolor='w',edgecolor='w')
        state=request.POST.get('state')
        print("state",state)
        df=pd.read_csv('rainfall in india 1901-2015.csv')
        #y=input('Enter a state: ')
        x = df[df['SUBDIVISION']==state]
        p=x.describe()
        bc=p.sort_values(by='max',axis=1,ascending=True)
        bc.drop(['YEAR','ANNUAL','Jan-Feb','Mar-May','Jun-Sep','Oct-Dec'],axis=1,inplace=True)
        bc.loc['max'].nlargest(5).plot.bar()
        a=bc.loc['max'].nlargest(5)
        plt.xlabel(state)
        #plt.xticks(rotate=45)
        buf=io.BytesIO()
        plt.savefig(buf,format='png')
        fig.savefig('abc.png')
        plt.close(fig)
        image=Image.open('abc.png')
        draw=ImageDraw.Draw(image)
        image.save(buf,'PNG')
        content_type='image/png'
        buffercontent=buf.getvalue()
        graphic=base64.b64encode(buffercontent)
       
        return render(request,'graphic.html',{'graphic': graphic.decode('utf-8'),'state':state})

def pred_year(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'pred_year.HTML',context=my_dict)

def visual_menu(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'visual_menu.html',context=my_dict)

def dynamic_visual_menu(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'dynamic_visual_menu.html',context=my_dict)

def stat_pred_menu(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'stat_pred_menu.html',context=my_dict)

def about_rainfall(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'about_rainfall.html',context=my_dict)

def about_temp(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'about_temp.html',context=my_dict)


def dynamic_prediction_2(request):
        year=0
        if request.method=='POST':
                print("posted")
                year=request.POST.get('year')
                year =int(year,0)
                print("number of years", year)
                fig=plt.figure(figsize=(6,7),dpi=80,facecolor="w",edgecolor="w")
                matplotlib.rcParams['axes.labelsize'] = 14
                matplotlib.rcParams['xtick.labelsize'] = 12
                matplotlib.rcParams['ytick.labelsize'] = 12
                matplotlib.rcParams['text.color'] = 'k'
                df = pd.read_csv("Max_Temp_IMD_2017.csv",index_col='YEAR',parse_dates=['YEAR'])
                print(df.index)
                cols = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC','JAN-FEB','MAR-MAY','JUN-SEP','OCT-DEC']
                df.drop(cols, axis=1, inplace=True)
                df = df.sort_values('YEAR')
                df.isnull().sum()
                df = df.diff(periods=1)
                df=df[1:]
                df.index
                crime = df.groupby('YEAR')['ANNUAL'].sum().reset_index()
                crime = crime.set_index('YEAR')
                crime.index

                from pylab import rcParams
                rcParams['figure.figsize'] = 18, 8
                decomposition = sm.tsa.seasonal_decompose(crime, model='additive')
                p = d = q = range(0, 2)
                pdq = list(itertools.product(p, d, q))
                seasonal_pdq = [(x[0], x[1], x[2], 12) for x in list(itertools.product(p, d, q))]
                print('Examples of parameter combinations for Seasonal ARIMA...')
                print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[1]))
                print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[2]))
                print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[3]))
                print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[4]))
                
                mod = sm.tsa.statespace.SARIMAX(crime,
                                order=(1,1,1),
                                seasonal_order=(1,1,1,12),
                               enforce_stationarity=False,
                                enforce_invertibility=False)
                results = mod.fit()
                print("result",results.summary().tables[1])
                pred_uc = results.get_forecast(steps=year)
                pred_ci = pred_uc.conf_int()
                ax = crime.plot(label='observed', figsize=(14, 7))
                pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
                buf=io.BytesIO()
                plt.savefig(buf,format='png')
                fig.savefig('abc.png')
                plt.close(fig)
                image=Image.open('abc.png')
                draw=ImageDraw.Draw(image)
                image.save(buf,'PNG')
                content_type="image/png"
                buffercontent=buf.getvalue()
                graphic=base64.b64encode(buffercontent)
                return render(request,'graphic.html',{'graphic':graphic.decode('utf-8'),'year':year})
        else:
                return HttpResponse("ok")
      
       
    


def pred_year_2(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'pred_year_2.HTML',context=my_dict)




def dynamic_visual_2(request):
    if request.method=='POST':
        
        year=request.POST.get('year')
        print("year",year)
        y=int(year)
        data=pd.read_csv('MAX_Temp_IMD_2017.csv')
        #y=int(input('Enter a year: '))
        x = data[data['YEAR']==y]
        p=x.describe()
        p=p.sort_values(by='max',axis=1,ascending=False)
        r=p.keys()
        print(r[1])
        bc=p.sort_values(by='max',axis=1,ascending=False)
        fig=plt.figure(figsize=(6,7),dpi=80,facecolor='w',edgecolor='w')
        bc.loc['max'].nlargest(6)[1:].plot.bar()
        a=bc.loc['max'].nlargest(6)
        plt.xlabel(a[0])
        #plt.show()
        buf=io.BytesIO()
        plt.savefig(buf,format='png')
        fig.savefig('abc.png')
        plt.close(fig)
        image=Image.open('abc.png')
        draw=ImageDraw.Draw(image)
        image.save(buf,'PNG')
        content_type='image/png'
        buffercontent=buf.getvalue()
        graphic=base64.b64encode(buffercontent)
       
    return render(request,'graphic.html',{'graphic': graphic.decode('utf-8'),'year':year})


def static_visualisation(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'static_visualisation.html',context=my_dict)

def static_visualisation_temp(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'static_visualisation_temp.html',context=my_dict)



def pred_temp(request):
    my_dict = {'insert_me':"hello i am from views.py !"}
    return render(request,'pred_temp.HTML',context=my_dict)




def dynamic_prediction_4(request):
        year=0
        if request.method=='POST':
                print("posted")
                year=request.POST.get('year')
                year =int(year,0)
                state=request.POST.get('state')
                print("number of years", year)
                fig=plt.figure(figsize=(6,7),dpi=80,facecolor="w",edgecolor="w")
                matplotlib.rcParams['axes.labelsize'] = 14
                matplotlib.rcParams['xtick.labelsize'] = 12
                matplotlib.rcParams['ytick.labelsize'] = 12
                matplotlib.rcParams['text.color'] = 'k'
                df = pd.read_csv("rainfall in india 1901-2015.csv",index_col='YEAR',parse_dates=['YEAR'])
                df=df[(df.SUBDIVISION==state) ]
                cols = ['SUBDIVISION','JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC','Jan-Feb','Mar-May','Jun-Sep','Oct-Dec']
                df.drop(cols, axis=1, inplace=True)
                df = df.sort_values('YEAR')
                df.isnull().sum()

                df.index
                crime = df.groupby('YEAR')['ANNUAL'].sum().reset_index()
                crime = crime.set_index('YEAR')
                crime.index

                from pylab import rcParams
                rcParams['figure.figsize'] = 14, 5
                decomposition = sm.tsa.seasonal_decompose(crime, model='additive')
                p = d = q = range(0, 2)
                pdq = list(itertools.product(p, d, q))
                seasonal_pdq = [(x[0], x[1], x[2], 12) for x in list(itertools.product(p, d, q))]
                print('Examples of parameter combinations for Seasonal ARIMA...')
                print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[1]))
                print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[2]))
                print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[3]))
                print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[4]))
                min=10000
                k=(0,0,0,0)
                for param in pdq:
                        for param_seasonal in seasonal_pdq:
                                try:
                                        mod = sm.tsa.statespace.SARIMAX(df,
                                                                order=param,
                                                                seasonal_order=param_seasonal,
                                                                enforce_stationarity=False,
                                                                enforce_invertibility=False)
                                        
                                        results = mod.fit()
                                        if results.aic<min:
                                                min=results.aic
                                                k=param_seasonal
                                        print('ARIMA{}x{}12 - AIC:{}'.format(param, param_seasonal, results.aic))
                                except:
                                        continue
                print("min",min," order is ",k)
                print("k[0]",k[0])
                print("k[1]",k[1])
                print("k[2]",k[2])
                
                mod = sm.tsa.statespace.SARIMAX(df,
                                        order=(0, 0, 1),
                                        seasonal_order=(k[0], k[1], k[2], k[3]),
                                        enforce_stationarity=False,
                                        enforce_invertibility=False)
                results = mod.fit()     
                print("result",results.summary().tables[1])
                pred_uc = results.get_forecast(steps=year)
                pred_ci = pred_uc.conf_int()
                ax = crime.plot(label='observed', figsize=(14, 7))
                pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
                buf=io.BytesIO()
                plt.savefig(buf,format='png')
                fig.savefig('abc.png')
                plt.close(fig)
                image=Image.open('abc.png')
                draw=ImageDraw.Draw(image)
                image.save(buf,'PNG')
                content_type="image/png"
                buffercontent=buf.getvalue()
                graphic=base64.b64encode(buffercontent)
                return render(request,'graphic.html',{'graphic': graphic.decode('utf-8'),'year':year})
        else:
                return HttpResponse("ok")

       
        